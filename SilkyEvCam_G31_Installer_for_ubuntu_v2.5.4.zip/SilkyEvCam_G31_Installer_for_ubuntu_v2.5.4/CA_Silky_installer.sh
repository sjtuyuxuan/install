#!/bin/bash
echo "CenturyArks SilkyEVCam installer"

RESOURCES_DIR="./resources"
LIB_INSTALL_PATH="/usr/lib/CenturyArks/hal/plugins"
TOOL_INSTALL_PATH="/usr/bin"
OS_VERSION_ID=$(cat /etc/os-release | grep VERSION_ID | awk -F\" '{print $2}'>&1)

if [ ! -d $RESOURCES_DIR/$OS_VERSION_ID ]; then
    echo "This OS version(${OS_VERSION_ID}) is not Supported."
    exit 1
fi

#install HAL plugin
sudo mkdir -p $LIB_INSTALL_PATH
sudo rm -f $LIB_INSTALL_PATH/*.so
sudo cp -p $RESOURCES_DIR/$OS_VERSION_ID/libevc3a_plugin_gen31.so $LIB_INSTALL_PATH

#install HAL tool
chmod +x $RESOURCES_DIR/$OS_VERSION_ID/silkyevcam_platform_info
sudo cp -p $RESOURCES_DIR/$OS_VERSION_ID/silkyevcam_platform_info $TOOL_INSTALL_PATH

#add CA plugin path to bashrc
echo "export MV_HAL_PLUGIN_PATH=$MV_HAL_PLUGIN_PATH":$LIB_INSTALL_PATH >> ~/.bashrc
source ~/.bashrc

#install udev rule for camera recognition
sudo cp -p $RESOURCES_DIR/ca_device.rules /etc/udev/rules.d

#register the udev rule
sudo udevadm control --reload-rules
